from fastapi import FastAPI

app = FastAPI()

@app.get("/health")
def health_check():
    return {"status": "healthy", "environment": "UAT"}

@app.get("/api/balance")
def get_balance():
    return {"account": "10029384", "balance": 50000, "currency": "INR"}