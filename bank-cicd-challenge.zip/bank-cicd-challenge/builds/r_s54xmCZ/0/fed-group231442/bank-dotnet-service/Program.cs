var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/health", () => new HealthResponse("healthy", "bank-dotnet-service", "UAT", ".NET 8.0"))
   .WithName("GetHealth");

app.MapGet("/api/loan-status", () => new LoanStatusResponse("LN-2026-9941", "Enterprise Customer", "APPROVED", 750000, "INR"))
   .WithName("GetLoanStatus");

app.Run();

public record HealthResponse(string status, string service, string environment, string stack);
public record LoanStatusResponse(string loanId, string applicant, string status, decimal amount, string currency);