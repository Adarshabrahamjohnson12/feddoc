# Universal Bank CI/CD Pipeline

A centralized CI/CD pipeline template designed to handle multi-language microservices (Python, .NET, Node.js, Java) without forcing individual teams to write and maintain their own deployment scripts.

## Why this exists
Usually, every team sets up their own pipeline, leading to fragmented configs and security drift. This repo acts as a single source of truth (`/templates/universal-pipeline.yml`). 

Downstream microservices don't duplicate pipeline logic—they just point to this template, and the pipeline automatically figures out how to test, build, and deploy them based on what project files are present.

---

## How it works (The 5-Stage Lifecycle)

When any service pushes code to GitLab, it runs through these automated stages:

1. **Validate (`validate_project`)**: Scans the repo root for manifest files (`.csproj`, `requirements.txt`, `package.json`, `pom.xml`) to auto-detect the tech stack.
2. **Test (`run_automated_tests`)**: Runs language-specific test runners (`pytest` for Python, `dotnet test` for .NET). Fails fast if tests break.
3. **Build (`build_artifact`)**: Compiles and packages release artifacts (e.g., `dotnet publish -c Release`).
4. **Deploy (`deploy_to_uat`)**: Safely kills any stale local processes (handling locked Windows DLLs), copies artifacts to an isolated UAT directory (`C:/UAT_Apps/`), and boots the service on its assigned port.
5. **Verify (`verify_uat_deployment`)**: Hits the live `/health` endpoint up to 5 times to confirm an `HTTP 200 OK` response before marking the pipeline green.

---

## Onboarding a New Service

To plug any new microservice into this pipeline, just add a `.gitlab-ci.yml` file to your repository root:

```yaml
include:
  - project: 'fed-group231442/bank-cicd-challenge'
    ref: main
    file: '/templates/universal-pipeline.yml'

variables:
  APP_NAME: "your-service-name"
  APP_PORT: "8082"  # Unique UAT port
  HEALTHCHECK_ENDPOINT: "/health"